package com.transaction.faiz.exception;

@SuppressWarnings("serial")
public class InsufficientAmountException extends RuntimeException{
	
	public InsufficientAmountException(String msg) {
		super(msg);
	}

}
