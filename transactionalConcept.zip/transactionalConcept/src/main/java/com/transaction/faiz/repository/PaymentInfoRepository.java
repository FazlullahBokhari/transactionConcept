package com.transaction.faiz.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.transaction.faiz.entity.PaymentInfo;


public interface PaymentInfoRepository extends JpaRepository<PaymentInfo, Long> {

	

}
