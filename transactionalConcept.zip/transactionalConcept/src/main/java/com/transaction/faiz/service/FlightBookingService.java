package com.transaction.faiz.service;

import java.util.UUID;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.SharedSessionContract;
//import org.hibernate.resource.transaction.spi.TransactionStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;
import org.springframework.transaction.support.TransactionTemplate;

import com.transaction.faiz.dto.FlightBookingAcknowledgement;
import com.transaction.faiz.dto.FlightBookingRequest;
import com.transaction.faiz.entity.PassengerInfo;
import com.transaction.faiz.entity.PaymentInfo;
import com.transaction.faiz.repository.PassengerInfoRepository;
import com.transaction.faiz.repository.PaymentInfoRepository;
import com.transaction.faiz.utils.PaymentUtils;

import jakarta.transaction.Transaction;

@Service
public class FlightBookingService {

	@Autowired
	private PassengerInfoRepository passengerInfoRepository;

	@Autowired
	private PaymentInfoRepository paymentInfoRepository;

	/*
	 * @Autowired private TransactionTemplate transactionTemplate;
	 */

	/*
	 * @Autowired private PlatformTransactionManager transactionManager;
	 */
	
	@Autowired
    private HibernateTransactionManager transactionManager;

	public FlightBookingAcknowledgement bookFlightTicket(FlightBookingRequest request) {
		
		
		
		DefaultTransactionDefinition def = new DefaultTransactionDefinition();
		def.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
		def.setIsolationLevel(TransactionDefinition.ISOLATION_READ_COMMITTED);
		def.setTimeout(30); // Timeout in seconds
		def.setReadOnly(false);
		TransactionStatus status = transactionManager.getTransaction(def);
		transactionManager.setRollbackOnCommitFailure(true);
		
        SessionFactory sessionFactory = transactionManager.getSessionFactory();
        Session session = sessionFactory.openSession();
        try {
            // Business logic for saving travel details
        	PassengerInfo passengerInfo = request.getPassengerInfo();
    		PassengerInfo savedDataPaasenger = passengerInfoRepository.save(passengerInfo);
    		PaymentInfo paymentInfo = request.getPaymentInfo();
    		PaymentUtils.validateCreditLimit(paymentInfo.getAccountNo(), passengerInfo.getFare());
    		paymentInfo.setPassengerId(savedDataPaasenger.getpId());
    		paymentInfo.setAmount(savedDataPaasenger.getFare());
    		paymentInfoRepository.save(paymentInfo);
    		
    		
    		transactionManager.commit(status);
            session.close();
    		return new FlightBookingAcknowledgement("Success", passengerInfo.getFare(),
    				UUID.randomUUID().toString().split("-")[0], passengerInfo);

        } catch (Exception ex) {
            if (!status.isCompleted()) {
                transactionManager.rollback(status);
            }
            session.close();
            throw ex;
        }

		/*
		 * TransactionStatus status = transactionManager.getTransaction(def);
		 * 
		 * try { // Business logic for saving travel details PassengerInfo passengerInfo
		 * = request.getPassengerInfo(); PassengerInfo savedDataPaasenger =
		 * passengerInfoRepository.save(passengerInfo); PaymentInfo paymentInfo =
		 * request.getPaymentInfo();
		 * PaymentUtils.validateCreditLimit(paymentInfo.getAccountNo(),
		 * passengerInfo.getFare());
		 * paymentInfo.setPassengerId(savedDataPaasenger.getpId());
		 * paymentInfo.setAmount(savedDataPaasenger.getFare());
		 * paymentInfoRepository.save(paymentInfo); transactionManager.commit(status);
		 * return new FlightBookingAcknowledgement("Success", passengerInfo.getFare(),
		 * UUID.randomUUID().toString().split("-")[0], passengerInfo);
		 * 
		 * } catch (Exception ex) { transactionManager.rollback(status); throw ex; }
		 */
		
		/*
		 * transactionTemplate.setPropagationBehavior(TransactionTemplate.
		 * PROPAGATION_REQUIRED);
		 * transactionTemplate.setIsolationLevel(TransactionTemplate.
		 * ISOLATION_READ_COMMITTED); transactionTemplate.setTimeout(30); // Timeout in
		 * seconds transactionTemplate.setReadOnly(false);
		 */
		

		/*
		 * return transactionTemplate.execute(status -> { try { // Business logic for
		 * saving travel details PassengerInfo passengerInfo =
		 * request.getPassengerInfo(); PassengerInfo savedDataPaasenger =
		 * passengerInfoRepository.save(passengerInfo);
		 * 
		 * 
		 * PaymentInfo paymentInfo = request.getPaymentInfo();
		 * 
		 * PaymentUtils.validateCreditLimit(paymentInfo.getAccountNo(),
		 * passengerInfo.getFare());
		 * 
		 * 
		 * 
		 * paymentInfo.setPassengerId(savedDataPaasenger.getpId());
		 * paymentInfo.setAmount(savedDataPaasenger.getFare());
		 * 
		 * paymentInfoRepository.save(paymentInfo);
		 * 
		 * return new
		 * FlightBookingAcknowledgement("Success",passengerInfo.getFare(),UUID.
		 * randomUUID().toString().split("-")[0], passengerInfo);
		 * 
		 * } catch (Exception ex) { status.setRollbackOnly(); throw ex; } });
		 */

	}

}
