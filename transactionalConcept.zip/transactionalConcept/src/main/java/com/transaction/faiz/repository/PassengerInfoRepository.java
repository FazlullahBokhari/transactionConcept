package com.transaction.faiz.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.transaction.faiz.entity.PassengerInfo;

public interface PassengerInfoRepository extends JpaRepository<PassengerInfo, Long> {

}
