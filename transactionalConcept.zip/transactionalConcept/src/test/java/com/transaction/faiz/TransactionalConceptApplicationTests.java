package com.transaction.faiz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransactionalConceptApplicationTests {

	@Test
	void contextLoads() {
	}

}
